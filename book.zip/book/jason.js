  const btn = document.querySelector('input');
  
btn.addEventListener("click", function(){
    alert("você comprou");
});

  