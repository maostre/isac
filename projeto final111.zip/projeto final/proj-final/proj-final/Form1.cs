

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace proj_final

    
{
    public partial class Form1 : Form
    {
        MySqlConnection Conexao;
              private  string data_source = "datasource=localhost;username=root;password=;database=db_agenda";
        public Form1()
        {
            InitializeComponent();

            lst_contatos.View = View.Details;
            lst_contatos.LabelEdit = true;
            lst_contatos.AllowColumnReorder = true;
            lst_contatos.FullRowSelect = true;
            lst_contatos.GridLines = true;




            lst_contatos.Columns.Add("ID", 30, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("Nome", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("Endenre�o", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("Telefone", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("RG", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("CPF", 150, HorizontalAlignment.Left);


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {

                Conexao = new MySqlConnection(data_source);
                Conexao.Open();

                string sql = "INSERT INTO contato (nome,email,telefone,cpf,rg,id)VALUES('"+txtNome+"','"+txtTelefone+"','"+txtendereco+"','"+txtCPF+ "','"+txtRG+"','"+txtID+"')";


                MySqlCommand comando = new MySqlCommand(sql, Conexao);
                comando.Connection = Conexao;

                Conexao = new MySqlConnection(data_source);

                if (txtID.Text == "")
                {
                    comando.CommandText = "INSERT INTO contato (nome,email,telefone,cpf,rg,id)VALUES('" + txtNome + "','" + txtTelefone + "','" + txtendereco + "','" + txtCPF + "','" + txtRG + "','" + txtID + "')";
                    comando.Parameters.AddWithValue("@nome",txtNome.Text);
                    comando.Parameters.AddWithValue("@email", txtemail.Text);
                    comando.Parameters.AddWithValue("@endere�o", txtendereco.Text);
                    comando.Parameters.AddWithValue("@ID", txtID.Text);

                    comando.Parameters.AddWithValue("@RG", txtRG.Text);

                    comando.Parameters.AddWithValue("@Telefone", txtTelefone.Text);
                    comando.Parameters.AddWithValue("@CPF", txtCPF.Text);

                MessageBox.Show("Inserido");

                }
                else
                {
                    comando.CommandText = "UPDATE contato SET nome=@nome, email=@email, endere�o=@endere�o, RG=@RG, Telefone=@telefone CPF=@CPF WHERE ID = @ID ";
                    comando.Parameters.AddWithValue("@nome", txtNome.Text);
                    comando.Parameters.AddWithValue("@email", txtemail.Text);
                    comando.Parameters.AddWithValue("@endere�o", txtendereco.Text);
                    comando.Parameters.AddWithValue("@ID", txtID.Text);

                    comando.Parameters.AddWithValue("@RG", txtRG.Text);

                    comando.Parameters.AddWithValue("@Telefone", txtTelefone.Text);
                    comando.Parameters.AddWithValue("@CPF", txtCPF.Text);
                    MessageBox.Show("Atualizado");

                }




            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Conexao.Close();  
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtID.Text == "")
                {
                    MessageBox.Show("Selecione um registro antes.",
                                    "Ops!",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }

                DialogResult confirmacao = MessageBox.Show("Tem certeza que deseja excluir?",
                                                           "Cuidado",
                                                           MessageBoxButtons.YesNo,
                                                           MessageBoxIcon.Warning);


                string q = "'%" + txtBuscar.Text + "%'";

                Conexao = new MySqlConnection(data_source);

                string sql = "SELECT * FROM contato WHERE nome  LIKE "+q +"OR email"+q;



                Conexao.Open();

                MySqlCommand comando = new MySqlCommand(sql, Conexao);
               MySqlDataReader reader = comando.ExecuteReader();
                lst_contatos.Items.Clear();

                while (reader.Read())
                {
                    string[] row =
                    {

                        reader.GetString(0),
                        reader.GetString(1),
                        reader.GetString(2),
                        reader.GetString(3),
                        reader.GetString(4),
                        reader.GetString(5)


                    };

                var linha_listview = new ListViewItem(row);

                lst_contatos.Items.Add(linha_listview);
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Conexao.Close();
            }
        }

        private void lst_contatos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {

        }

        private void lst_contatos_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            ListView.SelectedListViewItemCollection itens_selecionados = lst_contatos.SelectedItems;

            foreach (ListViewItem item in itens_selecionados)
            {
                txtNome.Text = item.SubItems[0].Text;
                txtID.Text = item.SubItems[1].Text;
                txtRG.Text = item.SubItems[2].Text;
                txtendereco.Text = item.SubItems[3].Text;
                txtCPF.Text = item.SubItems[4].Text;
                txtTelefone.Text = item.SubItems[5].Text;
                txtNome.Text = item.SubItems[6].Text;

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtNome.Text = "";
           txtCPF.Text = "";
            txtTelefone.Text = "";
            txtendereco.Text = "";
            txtRG.Text = "";
            
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}