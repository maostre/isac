function acao(){
   let modal = document.querySelector('.modal')

    modal.style.display = 'block';
   }
function fecha(){
   let modal = document.querySelector('.modal')

    modal.style.display = 'none';
   }
