
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;


namespace proj_final

    
{
    public partial class Form1 : Form
    {
        MySqlConnection Conexao;
              private  string data_source = "datasource=localhost;username=root;password=;database=db_agenda";
        private int ?id_contato_selecionado = null;
        public Form1()
        {
            InitializeComponent();

            lst_contatos.View = View.Details;
            lst_contatos.LabelEdit = true;
            lst_contatos.AllowColumnReorder= true;
            lst_contatos.FullRowSelect = true;
            lst_contatos.GridLines = true;




            lst_contatos.Columns.Add("ID", 30, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("Nome", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("Telefone", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("Endere�o", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("CPF", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("RG", 150, HorizontalAlignment.Left);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {

                Conexao = new MySqlConnection(data_source);

                Conexao.Open();

                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = Conexao;


                if(id_contato_selecionado == null)
                {
                    cmd.CommandText = "INSERT INTO contato (nome, endereco, telefone, cpf, rg, )VALUES (@nome, @endereco, @telefone, @cpf @rg, @id)";

                    cmd.Prepare();

                    cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                    cmd.Parameters.AddWithValue("@telefone", txtTelefone.Text);
                    cmd.Parameters.AddWithValue("@endereco", txtendereco.Text);
                    cmd.Parameters.AddWithValue("@cpf", txtCPF.Text);
                    cmd.Parameters.AddWithValue("@rg", txtRG.Text);


                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Ocorreu um erro" + MessageBoxIcon.Information);
                }
                else
                {
                    cmd.CommandText = "UPDATE contato SET (nome=@nome, endereco=@endere�o, telefone=@telefone, cpf=@cpf, rg=@rg" +
                        "WHERE id=@id"; 

                    cmd.Prepare();

                    cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                    cmd.Parameters.AddWithValue("@telefone", txtTelefone.Text);
                    cmd.Parameters.AddWithValue("@endereco", txtendereco.Text);
                    cmd.Parameters.AddWithValue("@cpf", txtCPF.Text);
                    cmd.Parameters.AddWithValue("@rg", txtRG.Text);
                    cmd.Parameters.AddWithValue("@id", id_contato_selecionado);



                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Ocorreu um erro" + MessageBoxIcon.Information);
                }










               

                /* string sql = "INSERT INTO contato (nome,email,telefone,cpf,rg,id)VALUES('"+txtNome+"','"+txtTelefone+"','"+txtemail+"','"+txtCPF+ "','"+txtRG+"','"+txtID+"')";


                 MySqlCommand comando = new MySqlCommand(sql, Conexao);

                 Conexao.Open();

                 comando.ExecuteReader();

                 MessageBox.Show("Inserido");*/



            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Conexao.Close();  
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {

                string q = "'%" + txtBuscar.Text + "%'";

                Conexao = new MySqlConnection(data_source);

                string sql = "SELECT * FROM contato WHERE nome  LIKE "+q +"OR email"+q;



                Conexao.Open();

                MySqlCommand comando = new MySqlCommand(sql, Conexao);
               MySqlDataReader reader = comando.ExecuteReader();
                lst_contatos.Items.Clear();

                while (reader.Read())
                {
                    string[] row = {

                    reader.GetString(0),
                        reader.GetString(1),
                        reader.GetString(2),
                        reader.GetString(3),
                        reader.GetString(4),
                        reader.GetString(5),

                        };
                var linha_listview = new ListViewItem(row);

                lst_contatos.Items.Add(linha_listview);
                };
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro" + ex.Number + "ocorreu" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro");
            }
            finally
            {
                Conexao.Close();
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void txtemail_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTelefone_TextChanged(object sender, EventArgs e)
        {

        }

        private void lst_contatos_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListView.SelectedListViewItemCollection itens_selecionados = lst_contatos.SelectedItems;

            foreach(ListViewItem item in itens_selecionados)
            {
                id_contato_selecionado = Convert.ToInt16(item.SubItems[0].Text);

                txtNome.Text = item.SubItems[1].Text;
                txtTelefone.Text = item.SubItems[2].Text;
                txtCPF.Text = item.SubItems[3].Text;
                txtRG.Text = item.SubItems[4].Text;
                txtendereco.Text = item.SubItems[5].Text;
                button3.Visible = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtCPF.Text = "";
            txtendereco.Text = "";
            txtNome.Text = "";
            txtTelefone.Text = "";
            txtRG.Text = "";
           button3.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            excluir_contato();
        }
       
        private void excluir_contato() 
            {
            try
            {
                DialogResult conf = MessageBox.Show("tem certeza que quer excluir?" + MessageBoxButtons.YesNo);

                if (conf == DialogResult.Yes)
                {
                    Conexao = new MySqlConnection(data_source);

                    Conexao.Open();

                    MySqlCommand cmd = new MySqlCommand();
                    cmd.Connection = Conexao;
                    cmd.CommandText = "DELETE FROKM contato WHERE id=@id";

                    cmd.Prepare();
                    cmd.Parameters.AddWithValue("@id", id_contato_selecionado);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("excluido");
                    button3.Visible = false;
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro" + ex.Number + "ocorreu" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            catch (Exception ex)
            {
                MessageBox.Show("ocorreu" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                Conexao.Close();
            }

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            excluir_contato();       
        }
    }
}