﻿namespace aula1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Txtnome = new System.Windows.Forms.TextBox();
            this.CBX = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RBTcarro = new System.Windows.Forms.RadioButton();
            this.RBTmoto = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.LBLdestino = new System.Windows.Forms.Label();
            this.LBLtransporte = new System.Windows.Forms.Label();
            this.TBXtotal = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BTNsair = new System.Windows.Forms.Button();
            this.BTNconfirmar = new System.Windows.Forms.Button();
            this.BTNlimpar = new System.Windows.Forms.Button();
            this.BTNcalculadora = new System.Windows.Forms.Button();
            this.BTNviagem = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(12, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Data de embarque";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(12, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Destino";
            // 
            // Txtnome
            // 
            this.Txtnome.BackColor = System.Drawing.Color.White;
            this.Txtnome.Location = new System.Drawing.Point(12, 26);
            this.Txtnome.Name = "Txtnome";
            this.Txtnome.Size = new System.Drawing.Size(148, 23);
            this.Txtnome.TabIndex = 4;
            // 
            // CBX
            // 
            this.CBX.FormattingEnabled = true;
            this.CBX.Items.AddRange(new object[] {
            "RJ ",
            "SP",
            "ES",
            "MG"});
            this.CBX.Location = new System.Drawing.Point(12, 83);
            this.CBX.Name = "CBX";
            this.CBX.Size = new System.Drawing.Size(148, 23);
            this.CBX.TabIndex = 5;
            this.CBX.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(13, 137);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(231, 23);
            this.dateTimePicker1.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.RBTcarro);
            this.groupBox1.Controls.Add(this.RBTmoto);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 182);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(342, 54);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Meio de transporte";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // RBTcarro
            // 
            this.RBTcarro.AutoSize = true;
            this.RBTcarro.Location = new System.Drawing.Point(10, 22);
            this.RBTcarro.Name = "RBTcarro";
            this.RBTcarro.Size = new System.Drawing.Size(54, 19);
            this.RBTcarro.TabIndex = 0;
            this.RBTcarro.TabStop = true;
            this.RBTcarro.Text = "Carro";
            this.RBTcarro.UseVisualStyleBackColor = true;
            this.RBTcarro.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // RBTmoto
            // 
            this.RBTmoto.AutoSize = true;
            this.RBTmoto.Location = new System.Drawing.Point(232, 22);
            this.RBTmoto.Name = "RBTmoto";
            this.RBTmoto.Size = new System.Drawing.Size(54, 19);
            this.RBTmoto.TabIndex = 0;
            this.RBTmoto.TabStop = true;
            this.RBTmoto.Text = "Moto";
            this.RBTmoto.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.LBLdestino);
            this.groupBox2.Controls.Add(this.LBLtransporte);
            this.groupBox2.Controls.Add(this.TBXtotal);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(392, 26);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(341, 264);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Valores do pacote";
            // 
            // LBLdestino
            // 
            this.LBLdestino.AutoSize = true;
            this.LBLdestino.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LBLdestino.Location = new System.Drawing.Point(168, 119);
            this.LBLdestino.Name = "LBLdestino";
            this.LBLdestino.Size = new System.Drawing.Size(50, 20);
            this.LBLdestino.TabIndex = 5;
            this.LBLdestino.Text = "label7";
            // 
            // LBLtransporte
            // 
            this.LBLtransporte.AutoSize = true;
            this.LBLtransporte.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LBLtransporte.Location = new System.Drawing.Point(188, 68);
            this.LBLtransporte.Name = "LBLtransporte";
            this.LBLtransporte.Size = new System.Drawing.Size(50, 20);
            this.LBLtransporte.TabIndex = 4;
            this.LBLtransporte.Text = "label7";
            // 
            // TBXtotal
            // 
            this.TBXtotal.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TBXtotal.Location = new System.Drawing.Point(144, 187);
            this.TBXtotal.Name = "TBXtotal";
            this.TBXtotal.Size = new System.Drawing.Size(172, 27);
            this.TBXtotal.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(22, 190);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Valor total";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(14, 119);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Gasto com destino";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(14, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Gasto com  transporte";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.BTNsair);
            this.panel1.Controls.Add(this.BTNconfirmar);
            this.panel1.Controls.Add(this.BTNlimpar);
            this.panel1.Controls.Add(this.BTNcalculadora);
            this.panel1.Controls.Add(this.BTNviagem);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 319);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 72);
            this.panel1.TabIndex = 9;
            // 
            // BTNsair
            // 
            this.BTNsair.BackColor = System.Drawing.Color.Black;
            this.BTNsair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNsair.ForeColor = System.Drawing.Color.White;
            this.BTNsair.Location = new System.Drawing.Point(697, 19);
            this.BTNsair.Name = "BTNsair";
            this.BTNsair.Size = new System.Drawing.Size(75, 41);
            this.BTNsair.TabIndex = 4;
            this.BTNsair.Text = "Sair";
            this.BTNsair.UseVisualStyleBackColor = false;
            this.BTNsair.Click += new System.EventHandler(this.BTNsair_Click);
            // 
            // BTNconfirmar
            // 
            this.BTNconfirmar.BackColor = System.Drawing.Color.Black;
            this.BTNconfirmar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNconfirmar.ForeColor = System.Drawing.Color.White;
            this.BTNconfirmar.Location = new System.Drawing.Point(601, 19);
            this.BTNconfirmar.Name = "BTNconfirmar";
            this.BTNconfirmar.Size = new System.Drawing.Size(75, 41);
            this.BTNconfirmar.TabIndex = 3;
            this.BTNconfirmar.Text = "Confirmar";
            this.BTNconfirmar.UseVisualStyleBackColor = false;
            this.BTNconfirmar.Click += new System.EventHandler(this.BTNconfirmar_Click);
            // 
            // BTNlimpar
            // 
            this.BTNlimpar.BackColor = System.Drawing.Color.Black;
            this.BTNlimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNlimpar.ForeColor = System.Drawing.Color.White;
            this.BTNlimpar.Location = new System.Drawing.Point(468, 19);
            this.BTNlimpar.Name = "BTNlimpar";
            this.BTNlimpar.Size = new System.Drawing.Size(117, 41);
            this.BTNlimpar.TabIndex = 2;
            this.BTNlimpar.Text = "limpar dados";
            this.BTNlimpar.UseVisualStyleBackColor = false;
            this.BTNlimpar.Click += new System.EventHandler(this.BTNlimpar_Click);
            // 
            // BTNcalculadora
            // 
            this.BTNcalculadora.BackColor = System.Drawing.Color.Black;
            this.BTNcalculadora.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNcalculadora.ForeColor = System.Drawing.Color.White;
            this.BTNcalculadora.Location = new System.Drawing.Point(244, 19);
            this.BTNcalculadora.Name = "BTNcalculadora";
            this.BTNcalculadora.Size = new System.Drawing.Size(86, 41);
            this.BTNcalculadora.TabIndex = 1;
            this.BTNcalculadora.Text = "Calculadora";
            this.BTNcalculadora.UseVisualStyleBackColor = false;
            this.BTNcalculadora.Click += new System.EventHandler(this.BTNcalculadora_Click);
            // 
            // BTNviagem
            // 
            this.BTNviagem.BackColor = System.Drawing.Color.Black;
            this.BTNviagem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTNviagem.ForeColor = System.Drawing.Color.White;
            this.BTNviagem.Location = new System.Drawing.Point(28, 19);
            this.BTNviagem.Name = "BTNviagem";
            this.BTNviagem.Size = new System.Drawing.Size(167, 41);
            this.BTNviagem.TabIndex = 0;
            this.BTNviagem.Text = "Calcular o valor da viagem";
            this.BTNviagem.UseVisualStyleBackColor = false;
            this.BTNviagem.Click += new System.EventHandler(this.BTNviagem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::aula1.Properties.Resources.a;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 391);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.CBX);
            this.Controls.Add(this.Txtnome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label2;
        private TextBox Txtnome;
        private ComboBox CBX;
        private DateTimePicker dateTimePicker1;
        private GroupBox groupBox1;
        private RadioButton RBTcarro;
        private RadioButton RBTmoto;
        private GroupBox groupBox2;
        private Panel panel1;
        private Button BTNsair;
        private Button BTNconfirmar;
        private Button BTNlimpar;
        private Button BTNcalculadora;
        private Button BTNviagem;
        private Label LBLdestino;
        private Label LBLtransporte;
        private TextBox TBXtotal;
        private Label label6;
        private Label label5;
        private Label label4;
    }
}