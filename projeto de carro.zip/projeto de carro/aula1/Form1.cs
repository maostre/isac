        using System.Diagnostics;

namespace aula1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void BTNlimpar_Click(object sender, EventArgs e)
        {
            Txtnome.Text = "";
            RBTcarro.Checked = false;
            RBTmoto.Checked = false;
            LBLdestino.Text = "";
            LBLtransporte.Text = "";

        }

        private void BTNcalculadora_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\windows\system32\calc.exe");
        }

        private void BTNsair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BTNconfirmar_Click(object sender, EventArgs e)
        {
            if(Txtnome.Text.Length == 0)
            {
                MessageBox.Show("digite o nome");
                Txtnome.Focus();
            }
            if (CBX.Text =="")
            {
                MessageBox.Show("Destino n�o escolhido");
                CBX.Focus();

            }
            if (RBTcarro.Checked == false && RBTmoto.Checked==false)
            {
                MessageBox.Show("Meio de transporte n�o escolhido");
                RBTmoto.Focus();

                RBTcarro.Focus();
            }
        }

        private void BTNviagem_Click(object sender, EventArgs e)
        {
            float GTdestino, GTtransporte, GTtotal;
            switch (CBX.Text.ToUpper())
            {
                case "RJ":
                    GTdestino = 1000f;
                    break;
                case "SP":
                    GTdestino = 2100f;
                    break;
                case "ES":
                    GTdestino = 3200f;
                    break;
                case "MG":
                    GTdestino = 4300f;
                    break;
                default: GTdestino = 0.0f;
                    break;
            }
            if (RBTcarro.Checked == true)
            
                GTtransporte = 100f;

            
            else
            
                GTtransporte = 30f;
                GTtotal = GTtransporte + GTdestino;
                        this.ClientSize = new System.Drawing.Size(533,441);
                        groupBox2.Visible = true;
                        LBLdestino.Text = GTdestino.ToString("C2");
                        LBLtransporte.Text = GTtransporte.ToString("C2");
                        TBXtotal.Text = GTtotal.ToString("C2");
            
            
        }
    }
}