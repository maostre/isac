const lis = document.querySelectorALL('.list');
function activ(){
    lis.forEach((item) =>
    item.classList.remove('active'));
    this.classList.add('active');

}
  lis.forEach((item) => 
  item.addEventlistener('click', activ)); 