


using MySql.Data.MySqlClient;


namespace proj_final

    
{
    public partial class Form1 : Form
    {
        MySqlConnection Conexao;
              private  string data_source = "datasource=localhost;username=root;password=;database=db_agenda";
        public Form1()
        {
            InitializeComponent();

            lst_contatos.Columns.Add("ID", 30, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("Nome", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("E-mail", 150, HorizontalAlignment.Left);
            lst_contatos.Columns.Add("Telefone", 150, HorizontalAlignment.Left);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {

                Conexao = new MySqlConnection(data_source);

                string sql = "INSERT INTO contato (nome,email,telefone,cpf,rg,id)VALUES('"+txtNome+"','"+txtTelefone+"','"+txtemail+"','"+txtCPF+ "','"+txtRG+"','"+txtID+"')";


                MySqlCommand comando = new MySqlCommand(sql, Conexao);

                Conexao.Open();

                comando.ExecuteReader();

                MessageBox.Show("Inserido");



            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Conexao.Close();  
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {

                string q = "'%" + txtBuscar.Text + "%'";

                Conexao = new MySqlConnection(data_source);

                string sql = "SELECT * FROM contato WHERE nome  LIKE "+q +"OR email"+q;



                Conexao.Open();

                MySqlCommand comando = new MySqlCommand(sql, Conexao);
               MySqlDataReader reader = comando.ExecuteReader();
                lst_contatos.Clear();

                while (reader.Read())
                {
                    string[] row =
                        reader.GetString(0),
                        reader.GetString(1),
                        reader.GetString(2),
                        reader.GetString(3),
                };

                var linha_listview = new ListViewItem(row);

                lst_contatos.Items.Add(linha_listview);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Conexao.Close();
            }
        }
    }
}