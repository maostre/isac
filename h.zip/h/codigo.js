
function duncc(){
    
    var dataAtual = new Date();
    var hour = dataAtual.getHours();
    var minute = dataAtual.getMinutes();
    var second = dataAtual.getSeconds();
    
    if(hour<10) hour = "0"+hour;
    if(minute<10) minute = "0"+minute;
    if(second<10) second = "0"+second;
    var tempo = hour+":"+minute+":"+second;
    document.getElementById("timer").innerHTML=tempo;
    
}
function timed(){
    setInterval(duncc,1000);
}

